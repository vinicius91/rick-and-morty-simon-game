export type SimonProp = {
  base: string,
  dark: string,
  sound: any
};

export type SimonProps = Array<simonProp>;
