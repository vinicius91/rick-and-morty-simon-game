module.exports = {
  clearMocks: true,
  coveragePathIgnorePatterns: ['/node_modules/'],
  coverageReporters: ['text'],
  testMatch: ['**/?(*.)+(spec|test).[tj]s?(x)']
};
